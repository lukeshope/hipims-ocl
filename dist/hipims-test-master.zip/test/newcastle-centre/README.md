Newcastle-upon-Tyne
=======

This is a simple test directly applying rainfall to a small part of the centre of Newcastle upon Tyne. The area has intentionally been selected as one which highlights some of the limitations of using these hydraulic models.

![Image of model domain](/test/newcastle-centre/media/domain.png?raw=true "Newcastle domain")

Inputs
------
To be completed.

Expected results
------
To be completed.

Data sources
------
Building outlines and roads are Crown Copyright © [Ordnance Survey](https://www.ordnancesurvey.co.uk/) 2016, used under [Open Government Licence](http://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/).
LiDAR data has been processed from the [Environment Agency Geomatics Group](http://www.geostore.com/environment-agency/survey.html#/survey), and is also used under [Open Government Licence](http://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/).
